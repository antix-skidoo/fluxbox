this archivefile contains 500 fluxfox styles
along with html pages providing a "preview" of each style.


Some of the styles (approx 100) contained in the archivefile here were retrieved from the now defunct "fluxmod.dk" website, bearing a license declaration stating "Creative Commons Attribution 3.0"

The other (approx 400) styles contained in the archivefile here were retrieved from http ... tenr.de, accompanied by a statement declaring"
-=-
I host these styles that were created by various artists.
I want you to know I did not make them, I dont want credit for them,
Each style should contain license, and should also have the authors name
as well as contact info for getting a hold of them. All I am doing is providing
easy access to the old "fluxbmod-style". Themes (sic) are owned by the creator.
Please also follow the probably included license information in the themes (sic).
If an author feels offended by me for providing the style please contact me (at "tenr dot de")
-=-
As of June 2019, the tenr.de site is still available (page is marked LastUpdated: 2013)

At the tenr.de site, styles are presented across 19 (?) webpages.
A "preview" thumbnail image is displayed for each style; clicking initiates download of a tar.bz file containing the assets for an individual style.

skidoo scraped the "preview" images for each style from tenr.de, embedded them into 2 loooooong html files, and placed the extracted content of the myriad tar.bz files to subdirectories within the "500" archivefile.

When viewing the local html files in web browser, clicking a preview navigates to the subdirectory containing the style of interest. You can copy the directory path, from browser addressbar to (commandline or) file manager pathbar, and transfer its content to ~/.fluxbox/sytles/<styleNameSubdirectory>
















note-to-self: xref "ax16::500_fluxstyles.tar.gz"
